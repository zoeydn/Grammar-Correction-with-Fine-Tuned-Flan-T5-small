ABCN.test.bea19.orig is the official test file of the BEA-2019 Shared Task. 

It is only available in tokenised plain text format since we withhold the gold annotations in the interest of fairness. 

Any output generated from this file should be submitted to the Codalab competition platform to be evaluated. For more information on how to do this, see the Codalab website:

Restricted Track: https://competitions.codalab.org/competitions/20228
Unrestricted Track: https://competitions.codalab.org/competitions/20229
Low Resource Track: https://competitions.codalab.org/competitions/20230