# Turn the m2 train file into a jsonl file with instructions
import json

def find_sentence(m2_path):
    with open(m2_path, "r", encoding="utf-8") as file:
        sent_list = []
        block = []
        for line in file:
            line = line.strip()
            if line:
                block.append(line)
            else:
                if block:
                    sent_list.append(block)
                    block = []
        if block:
            sent_list.append(block)
        return sent_list

def apply_edits(input_sentence, edits):
    tokens = input_sentence.split()
    for start, end, correction in sorted(edits, reverse=True):
        tokens[start:end] = [correction]
    return " ".join(tokens)

def to_instruction_format(sent_list, output_path):
    with open(output_path, "w", encoding="utf-8") as f:
        for item in sent_list:
            input_sentence = ""
            edits = []

            for line in item:
                if line.startswith("S "):
                    input_sentence = line[2:].strip()
                elif line.startswith("A ") and "|||noop|||" not in line:
                    parts = line.split("|||")
                    span = parts[0].split()
                    start, end = int(span[1]), int(span[2])
                    correction = parts[2].strip()
                    edits.append((start, end, correction))

            if edits:
                corrected = apply_edits(input_sentence, edits)
            else:
                corrected = input_sentence

            json_line = json.dumps({
                "instruction": "Correct the grammar in this sentence:",
                "input": input_sentence,
                "output": corrected
            })
            f.write(json_line + "\n")

def main():
    m2_file = "/wi+locness/m2/ABC.train.gold.bea19.m2"
    output_jsonl = "ABC.train.gold.bea19.jsonl"

    sent_list = find_sentence(m2_file)
    to_instruction_format(sent_list, output_jsonl)

if __name__ == "__main__":
    main()
