#Split dev set into a new dev set and a new test set.
from datasets import Dataset

path = "/wi+locness/m2/ABCN.dev.gold.bea19.jsonl"
dev_full = Dataset.from_json(path)

split = dev_full.train_test_split(test_size=0.5, seed=42)
new_dev = split["train"]
new_test = split["test"]

new_dev.to_json("new_dev.jsonl")
new_test.to_json("new_test.jsonl")
